
const char* getpass();
