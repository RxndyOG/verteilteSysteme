# LDAP Sample in C
